The functions provided here are used to report results in the following paper. Please cite the paper if you use it in your research.

Hossein Ziaei Nafchi and Mohamed Cheriet: Efficient No-Reference Quality Assessment and Classification Model for Contrast Distorted Images, 
IEEE Transactions on Broadcasting, 2018.
