# Evaluate_Image_Quality

## Image evaluation index
- Statisics
   - max pixel value
   - min pixel value
   - mean pixel value
   - std
- NMSE(Normalized mean square error)
- PSNR(Peak signal-to-noise ratio)
- Entropy